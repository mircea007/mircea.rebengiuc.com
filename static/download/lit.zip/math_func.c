#include "grafica.h"

// roteste obiectul descris in faces[][] si il stocheaza in rot[][]
void transfObject( struct Mesh *faces, struct Mesh *rot, double alphax, double alphay, double alphaz ) {
  int i, j, p;
  double x, y, z;
  double sinx = sin( alphax );
  double siny = sin( alphay );
  double sinz = sin( alphaz );
  double cosx = cos( alphax );
  double cosy = cos( alphay );
  double cosz = cos( alphaz );

  rot->np = faces->np;
  rot->nf = faces->nf;

  // colors are the same
  for( p = 0 ; p < faces->np ; p++ )
    rot->pc[p] = faces->pc[p];

  // face pointers are the same
  for( i = 0 ; i < faces->nf ; i++ )
    for( j = 0 ; j < POINTS_PER_SIDE ; j++ )
      rot->fp[i][j] = faces->fp[i][j];

  // move points
  for ( p = 0 ; p < faces->np ; p++ ){
    // PUNCT
    
    // rotatie in jurul axei x
    rot->p[p].x = x = faces->p[p].x;
    rot->p[p].y = y = faces->p[p].y * cosx - faces->p[p].z * sinx;
    rot->p[p].z = z = faces->p[p].y * sinx + faces->p[p].z * cosx;

    // rotatie in jurul axei y
    rot->p[p].z = z * cosy - x * siny;
    x = rot->p[p].x = z * siny + x * cosy;

    // rotatie in jurul axei z
    rot->p[p].x = x * cosz - y * sinz;
    rot->p[p].y = x * sinz + y * cosz;

    // NORMALA

    // rotatie in jurul axei x
    rot->norm[p].x = x = faces->norm[p].x;
    rot->norm[p].y = y = faces->norm[p].y * cosx - faces->norm[p].z * sinx;
    rot->norm[p].z = z = faces->norm[p].y * sinx + faces->norm[p].z * cosx;

    // rotatie in jurul axei y
    rot->norm[p].z = z * cosy - x * siny;
    x = rot->norm[p].x = z * siny + x * cosy;

    // rotatie in jurul axei z
    rot->norm[p].x = x * cosz - y * sinz;
    rot->norm[p].y = x * sinz + y * cosz;
  }
}

// face proiectia perspectiva
int perspective( struct point *fuga, struct point *p, double *x, double *y ){
  double dx, dy, dz, plane_z;

  if( p->z >= fuga->z )
    return 0;

  dx = fuga->x - p->x;
  dy = fuga->y - p->y;
  dz = fuga->z - p->z;

  // the screen is at z=2
  plane_z = fuga->z - 2;
  *x = -(fuga->x + dx * plane_z / dz);
  *y = fuga->y + dy * plane_z / dz;

  return 1;
}

// face proiectia paralela
int paralel( struct point *useless, struct point *p, double *x, double *y ){
  *x = p->x;
  *y = -(p->y);

  return 1;
}


void getObjectLighting( struct Mesh *faces, struct point light_dir ){
  int p;
  double cosa, mod_norm, mod_light = sqrt( light_dir.x * light_dir.x + light_dir.y * light_dir.y + light_dir.z * light_dir.z );

  for( p = 0 ; p < faces->np ; p++ ){
    mod_norm = sqrt( faces->norm[p].x * faces->norm[p].x
                   + faces->norm[p].y * faces->norm[p].y
                   + faces->norm[p].z * faces->norm[p].z );
    cosa = (faces->norm[p].x * light_dir.x
          + faces->norm[p].y * light_dir.y
          + faces->norm[p].z * light_dir.z ) / (mod_light * mod_norm);
    faces->pc[p].r = faces->pc[p].b = faces->pc[p].g = (cosa + 1) / 2 * MAX_COL;
  }
}
