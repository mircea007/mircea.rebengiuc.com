#include "grafica.h"
#include <unistd.h>

// heap memory

// point matricies
#ifndef CUBE
struct Mesh faces;
#else// DOESN'T WORK, DOES'T INCLUDE SIZES
struct Mesh faces = {
  {
    {  1,  1,  1 },// 0
    { -1,  1,  1 },// 1
    {  1, -1,  1 },// 2
    { -1, -1,  1 },// 3
    {  1,  1, -1 },// 4
    { -1,  1, -1 },// 5
    {  1, -1, -1 },// 6
    { -1, -1, -1 },// 7
  },
  {},
  {
    { 0, 4, 6, 2 },
    { 7, 3, 1, 5 },
    { 0, 4, 5, 1 },
    { 7, 3, 2, 6 },
    { 0, 1, 3, 2 },
    { 7, 6, 4, 5 },
  }
};
#endif
struct Mesh rot;

unsigned char ch2seg[128];

function *fun[NUM_FUNC] = {
  &eggpack,
  &wave,
  &hat,
  &cone,
  &sarpe,
  &crazytube,
  &donut,
};

proj *projections[NUM_PROJ] = {
  &paralel,
  &perspective,
};

double size[NUM_FUNC][2] = {
  { 4 * M_PI, 4 * M_PI },
  { 2 * M_PI, 4 * M_PI },
  { 2 * M_PI, 2.2 },
  { 1, 3 },
  { 4 * M_PI, 1 },
  { 4 * M_PI, 1 },
  { 1, 3 },
};

int densities[NUM_FUNC][2] = {
  { MESH_DENSITY, MESH_DENSITY },
  { 60,           MESH_DENSITY },
  { 60,           MESH_DENSITY },
  { 60,           60 },
  { MESH_DENSITY, 60 },
  { MESH_DENSITY, 60 },
  { 60          , 60 },
};

int main( int argc, char* argv[] ){
  SDL_Window* window = NULL;
  SDL_Renderer* renderer = NULL;
  SDL_Event event;
  SDL_bool done, proj = 1, valid_key = 0, crosshair = 1;
  SDL_Color col = { 0, 255, 0 };// line color -- cyan
  SDL_Color bg_col = { 0, 0, 0 };// backgournd color -- black
  double scale = DEFAULT_SCALE;
  double alphax = 0.0, alphay = 0.0, alphaz = 0.0;
  struct point fuga = { 0, 0, 7 }, light_dir = { 2, -2, -2 };
  int w = 800, h = 800;
  double fps;
  long long prev = getTimeStamp(), now;
  int object = 0;

#ifdef CUBE
  int i;
  for( i = 0 ; i < NPOINTS ; i++ ){
    faces.pc[i].r = (faces.p[i].x > 0) * 255;
    faces.pc[i].g = (faces.p[i].y > 0) * 255;
    faces.pc[i].b = (faces.p[i].z > 0) * 255;
    faces.pc[i].a = SDL_ALPHA_OPAQUE;
  }
#endif

  if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
    fprintf(stderr, "Unable to initialize SDL:  %s\n", SDL_GetError());// daca nu a reusit sa se initializeze SDL
    return 1;
  }else{
    fprintf(stderr, "SDL initialized successfully!\n");
  }

  if (SDL_CreateWindowAndRenderer(800, 800, SDL_WINDOW_RESIZABLE, &window, &renderer) == 0) {
    done = SDL_FALSE;
    alphax = M_PI / 2;
    alphay = alphaz = 0;
    object = 0;

    SDL_SetWindowTitle(window, "program grafica 3D iluminare");// titlu fereastra

    initSevenSegment( ch2seg );// initializam fontul

    // generam obiectul
    fun[object]( &faces, size[object][0], size[object][1], densities[object][0], densities[object][1] );
    getNorm( &faces );
    
    // prima afisare
    transfObject( &faces, &rot, alphax, alphay, alphaz );
    getObjectLighting( &rot, light_dir );

    now = getTimeStamp();
    fps = 1000000 / (now - prev);
    prev = now;

    renderObjectPerspective( &rot, renderer, projections[proj], &fuga, w / 2, h / 2, scale, &col, &bg_col, crosshair );
    renderInfo( renderer, &col, fps, object, ch2seg );
    SDL_RenderPresent(renderer);
    
    // bucla de evenimente
    while (!done) {
      if (SDL_WaitEvent(&event)) {// asteapta pana la urmatorul event
        switch ( event.type ) {
        case SDL_WINDOWEVENT:
          valid_key = 1;
          switch( event.window.event ){
          case SDL_WINDOWEVENT_RESIZED:
            w = event.window.data1;
            h = event.window.data2;
            break;
          }
          break;
        case SDL_QUIT:
          valid_key = 0;
          done = SDL_TRUE;
          break;
        case SDL_MOUSEWHEEL:
          valid_key = 0;
          if( event.wheel.y > 0 ){
            scale *= 2;
            valid_key = 1;
          }else if( event.wheel.y < 0 ){
            scale /= 2;
            valid_key = 1;
          }
          break;
        case SDL_KEYUP:
          valid_key = 0;
          switch ( event.key.keysym.sym ) {
            //case SDLK_RCTRL:
            //case SDLK_LCTRL:
            //control = 0;
          default:
            valid_key = 0;
          }
          break;
        case SDL_KEYDOWN:
          valid_key = 1;
          switch ( event.key.keysym.sym ) {
          case SDLK_q:
            alphax += DALPHA;
            break;
          case SDLK_a:
            alphax -= DALPHA;
            break;
          case SDLK_s:
            alphay -= DALPHA;
            break;
          case SDLK_d:
            alphay += DALPHA;
            break;
          case SDLK_9:
            alphaz -= DALPHA;
            break;
          case SDLK_0:
            alphaz += DALPHA;
            break;
            //case SDLK_RCTRL:
            //case SDLK_LCTRL:
            //control = 1;
            //break;
          case SDLK_RIGHT:
            object = (object + 1) % NUM_FUNC;
            fun[object]( &faces, size[object][0], size[object][1], densities[object][0], densities[object][1] );
            getNorm( &faces );
            break;
          case SDLK_LEFT:
            object = (object + NUM_FUNC - 1) % NUM_FUNC;
            fun[object]( &faces, size[object][0], size[object][1], densities[object][0], densities[object][1] );
            getNorm( &faces );
            break; 
          case SDLK_c:
            crosshair ^= 1;
            break;
          case SDLK_p:
            proj = (proj + 1) % NUM_PROJ;
            break;
         default:
            valid_key = 0;
          }
          break;
        default:
          valid_key = 0;
        }
        if( valid_key ){
          // daca s-a intamplat ceva nou redesenam cubul
          transfObject( &faces, &rot, alphax, alphay, alphaz );
          getObjectLighting( &rot, light_dir );
          
          now = getTimeStamp();
          fps = 1000000 / (now - prev);
          prev = now;
          
          renderObjectPerspective( &rot, renderer, projections[proj], &fuga, w / 2, h / 2, scale, &col, &bg_col, crosshair );
          renderInfo( renderer, &col, fps, object, ch2seg );
          SDL_RenderPresent(renderer);
        }
      }
    }
  }

  if (renderer) {// inchidem renderer
    SDL_DestroyRenderer(renderer);
  }
  if (window) {// inchidem fereastra
    SDL_DestroyWindow(window);
  }

  // inchidem SDL
  SDL_Quit();

  printf("quit\n");// mesaj de oprire :)
  return 0;
}
