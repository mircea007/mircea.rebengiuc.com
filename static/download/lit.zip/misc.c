#include "grafica.h"

long long getTimeStamp() {
  struct timeval tv;
  
  gettimeofday(&tv,NULL);
  
  return tv.tv_sec * (long long)1000000 + tv.tv_usec;
}

/*

  --a--
 |     |
 f     b
 |     |
  --g--
 |     |
 e     c
 |     |
  --d--


*/

void initSevenSegment( unsigned char ch2seg[128] ){
  int i;
  
  // https://en.wikipedia.org/wiki/Seven-segment_display#Hexadecimal

  for( i = 0 ; i < 128 ; i++ )
    ch2seg[i] = 0;
  
  ch2seg[(int)'0'] = 0x7e;
  ch2seg[(int)'1'] = 0x30;
  ch2seg[(int)'2'] = 0x6d;
  ch2seg[(int)'3'] = 0x79;
  ch2seg[(int)'4'] = 0x33;
  ch2seg[(int)'5'] = 0x5b;
  ch2seg[(int)'6'] = 0x5f;
  ch2seg[(int)'7'] = 0x70;
  ch2seg[(int)'8'] = 0x7f;
  ch2seg[(int)'9'] = 0x7b;
  ch2seg[(int)'f'] = 0x47;
  ch2seg[(int)'p'] = 0x67;
  ch2seg[(int)'s'] = 0x5b;
  ch2seg[(int)'o'] = 0x1d;
  ch2seg[(int)'b'] = 0x1f;
  ch2seg[(int)'j'] = 0x38;
  ch2seg[(int)' '] = 0;
}
