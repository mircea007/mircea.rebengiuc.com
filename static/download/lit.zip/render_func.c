#include "grafica.h"

#define MAXY 4096// inaltimea maxima a monitorului
#define MAXX 8192// latimea maxima a monitorului

// pune un punct pe un SDL_Surface
static inline void putpixel( SDL_Surface *surf, int x, int y, unsigned int colorcode ){
  unsigned int* pixels = (unsigned int*)surf->pixels;

  if( y < 0 || y >= surf->h || x < 0 || x >= surf->w )
    return;
  
  pixels[y * (surf->w) + x] = colorcode;
}

static inline int getpixel( SDL_Surface *surf, int x, int y ){
  unsigned int* pixels = (unsigned int*)surf->pixels;

  if( y < 0 || y >= surf->h || x < 0 || x >= surf->w )
    return -1;
  
  return pixels[y * (surf->w) + x];
}

static inline int getColorCode( int r, int g, int b, int a ){
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
  return a | (b << 8) | (g << 16) | (r << 24);
#else
  return r | (g << 8) | (b << 16) | (a << 24);
#endif
}

static inline void getColorRGBA( unsigned int code, SDL_Color *col ){
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
  col->a = (code & 0xff);
  col->b = ((code & 0xff00) >> 8);
  col->g = ((code & 0xff0000) >> 16);
  col->r = ((code & 0xff000000) >> 24);
#else
  col->r = (code & 0xff);
  col->g = ((code & 0xff00) >> 8);
  col->b = ((code & 0xff0000) >> 16);
  col->a = ((code & 0xff000000) >> 24);
#endif
}

static inline void invpixel( SDL_Surface *surf, int x, int y ){
  unsigned int* pixels = (unsigned int*)surf->pixels;

  if( y < 0 || y >= surf->h || x < 0 || x >= surf->w )
    return;
  
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
  pixels[y * (surf->w) + x] ^= 0xffffff00;
#else
  pixels[y * (surf->w) + x] ^= 0x00ffffff;
#endif
}

// deseneaza linie cu Bresenham
// este generalizat pentru oricare orientare a linii
void bresenham( SDL_Surface *surf, struct point2d *coord1, struct point2d *coord2, SDL_Color *c1, SDL_Color *c2 ){
  int current[5], semn[5], d[5], p1[5], p2[5], p[5], jump[5], main, i;

  p1[0] = coord1->x;
  p1[1] = coord1->y;
  p1[2] = c1->r;
  p1[3] = c1->g;
  p1[4] = c1->b;

  p2[0] = coord2->x;
  p2[1] = coord2->y;
  p2[2] = c2->r;
  p2[3] = c2->g;
  p2[4] = c2->b;

  for( i = 0 ; i < 5 ; i++ ){
    current[i] = p1[i];
    jump[i] = 0;
    
    d[i] = p2[i] - p1[i];
    if( d[i] < 0 ){
      d[i] = -d[i];
      semn[i] = -1;
    }else
      semn[i] = 1;
  }

  main = 0;
  for( i = 1 ; i < 2 ; i++ )// nu vrem ca main sa fie o culoare deci limitam la x, y
    main = d[i] > d[main] ? i : main;

  for( i = 2 ; i < 5 ; i++ ){// mergem prin culori
    if( d[main] ){
      jump[i] = d[i] / d[main];
      d[i] %= d[main];
    }else
      jump[i] = d[i] = 0;
  }
    
  for( i = 0 ; i < 5 ; i++ )
    p[i] = 2 * d[i] - d[main];

  while( current[main] != p2[main] ){
    putpixel(surf, current[0], current[1], getColorCode(current[2], current[3], current[4], SDL_ALPHA_OPAQUE));
    
    for( i = 0 ; i < 5 ; i++ ){
      current[i] += jump[i] * semn[i];
      if( p[i] > 0 ){
        p[i] -= (d[main] << 1);
        current[i] += semn[i];
      }
      p[i] += (d[i] << 1);
    }
  }

  putpixel(surf, p2[0], p2[1], getColorCode(p2[2], p2[3], p2[4], SDL_ALPHA_OPAQUE));
}

// inverseaza culorile de pe o linie cu Bresenham
// este generalizat pentru oricare orientare a linii
void bresenhamInv( SDL_Surface *surf, struct point2d *coord1, struct point2d *coord2 ){
  int current[2], semn[2], d[2], p1[2], p2[2], p[2], main, i;

  p1[0] = coord1->x;
  p1[1] = coord1->y;

  p2[0] = coord2->x;
  p2[1] = coord2->y;

  for( i = 0 ; i < 2 ; i++ ){
    current[i] = p1[i];
    
    d[i] = p2[i] - p1[i];
    if( d[i] < 0 ){
      d[i] = -d[i];
      semn[i] = -1;
    }else
      semn[i] = 1;
  }

  main = 0;
  for( i = 1 ; i < 2 ; i++ )
    main = d[i] > d[main] ? i : main;

  for( i = 0 ; i < 2 ; i++ )
    p[i] = 2 * d[i] - d[main];

  while( current[main] != p2[main] ){
    invpixel(surf, current[0], current[1]);
    
    for( i = 0 ; i < 2 ; i++ ){
      if( p[i] > 0 ){
        p[i] -= (d[main] << 1);
        current[i] += semn[i];
      }
      p[i] += (d[i] << 1);
    }
  }

  invpixel(surf, p2[0], p2[1]);
}

// deseneaza linie cu Bresenham
// este generalizat pentru oricare orientare a linii
// ATENTIE: ESTE MODIFICAT PENTRU FUNCTIA fillpollyconvex()
// pentru bresenham normal folositi functia bresenham()
void bresenhamMod( SDL_Surface *surf, struct point2d *coord1, struct point2d *coord2, SDL_Color *c1, SDL_Color *c2, int minx[], int maxx[], unsigned int minc[], unsigned int maxc[] ){
  int current[5], semn[5], d[5], p1[5], p2[5], p[5], jump[5], main, i;
  unsigned int colcode;

  p1[0] = coord1->x;
  p1[1] = coord1->y;
  p1[2] = c1->r;
  p1[3] = c1->g;
  p1[4] = c1->b;

  p2[0] = coord2->x;
  p2[1] = coord2->y;
  p2[2] = c2->r;
  p2[3] = c2->g;
  p2[4] = c2->b;

  for( i = 0 ; i < 5 ; i++ ){
    current[i] = p1[i];
    jump[i] = 0;
    
    d[i] = p2[i] - p1[i];
    if( d[i] < 0 ){
      d[i] = -d[i];
      semn[i] = -1;
    }else
      semn[i] = 1;
  }

  main = 0;
  for( i = 1 ; i < 2 ; i++ )// nu vrem ca main sa fie o culoare deci limitam la x, y
    main = d[i] > d[main] ? i : main;

  for( i = 2 ; i < 5 ; i++ ){// mergem prin culori
    if( d[main] ){
      jump[i] = d[i] / d[main];
      d[i] %= d[main];
    }else
      jump[i] = d[i] = 0;
  }

  for( i = 0 ; i < 5 ; i++ )
    p[i] = 2 * d[i] - d[main];

  while( current[main] != p2[main] ){
    putpixel(surf, current[0], current[1], (colcode = getColorCode(current[2], current[3], current[4], SDL_ALPHA_OPAQUE)));

    if( current[1] >= 0 && current[1] < MAXY ){
      // actualizam culorile de la capete
      if( current[0] <= minx[current[1]] ){
        minx[current[1]] = current[0];
        minc[current[1]] = colcode;
      }

      if( current[0] >= maxx[current[1]] ){
        maxx[current[1]] = current[0];
        maxc[current[1]] = colcode;
      }
    }
    
    for( i = 0 ; i < 5 ; i++ ){
      current[i] += jump[i] * semn[i];
      if( p[i] > 0 ){
        p[i] -= (d[main] << 1);
        current[i] += semn[i];
      }
      p[i] += (d[i] << 1);
    }
  }

  putpixel(surf, p2[0], p2[1], getColorCode(p2[2], p2[3], p2[4], SDL_ALPHA_OPAQUE));

  if( current[1] >= 0 && current[1] < MAXY ){
    // actualizam culorile de la capete
    if( current[0] <= minx[current[1]] ){
      minx[current[1]] = current[0];
      minc[current[1]] = colcode;
    }

    if( current[0] >= maxx[current[1]] ){
      maxx[current[1]] = current[0];
      maxc[current[1]] = colcode;
    }
  }
}

/*

  0--1
  |  |
  2--3
  |  |
  4--5

*/

void renderSevenSegChar( SDL_Surface *surf, SDL_Color *fg, int x, int y, unsigned char led_state ){
  int seg_start[7] = { 2, 2, 4, 5, 3, 1, 0 };
  int seg_end[7]   = { 3, 0, 2, 4, 5, 3, 1 };
  int i;
  struct point2d p1, p2;

  led_state &= 0x7f;

  for( i = 0 ; i < 7 ; i++ ){
    if( led_state & 1 ){// este aprins segmentul i?
      p1.x = x + TEXT_SIZE * (seg_start[i] & 1);
      p1.y = y + TEXT_SIZE * (seg_start[i] >> 1);

      p2.x = x + TEXT_SIZE * (seg_end[i] & 1);
      p2.y = y + TEXT_SIZE * (seg_end[i] >> 1);

      bresenham(surf, &p1, &p2, fg, fg);
    }
    led_state >>= 1;
  }
}

void renderSevenSegStr( SDL_Surface *surf, const char *str, SDL_Color *fg, int x, int y, unsigned char ch2seg[128] ){
  while( *str ){
    renderSevenSegChar(surf, fg, x, y, ch2seg[tolower(*str)]);

    x += TEXT_SIZE + TEXT_CH_DIST;
    str++;
  }
}

void fillpollyconvex( SDL_Surface *surf, struct point2d *v[], SDL_Color *col[], int n ){
  int minx[MAXY];
  int maxx[MAXY];
  unsigned int minc[MAXY];
  unsigned int maxc[MAXY];

  int i, miny = MAXY + 1, maxy = -1, scan;
  SDL_Color c1, c2;
  struct point2d p1, p2;
  
  // initializare minx, maxx
  for( i = 0 ; i < n ; i++ ){
    miny = v[i]->y < miny ? v[i]->y : miny;
    maxy = v[i]->y > maxy ? v[i]->y : maxy;
  }
  miny = miny < 0 ? 0 : miny;
  maxy = maxy >= MAXY ? MAXY - 1 : maxy;

  for( scan = miny ; scan <= maxy ; scan++ ){
    minx[scan] = MAXX - 1;
    maxx[scan] = 0;
  }

  // desenam liniile
  for( i = 0 ; i < n ; i++ )
    bresenhamMod(surf, v[i], v[(i + 1) % n], col[i], col[(i + 1) % n], minx, maxx, minc, maxc);

  // completam interiorul
  for( scan = miny ; scan <= maxy ; scan++ ){
    p1.y = p2.y = scan;
    p1.x = minx[scan];
    p2.x = maxx[scan];

    getColorRGBA(minc[scan], &c1);
    getColorRGBA(maxc[scan], &c2);

    bresenham(surf, &p1, &p2, &c1, &c2);
  }
}

// afiseaza obiectul din faces[][] pe ecran
/*void renderObjectParalel( struct point faces[NFACES][POINTS_PER_SIDE], SDL_Renderer* renderer, double xshift, double yshift, double scale, int hide, SDL_Color *col, SDL_Color *bg_col ) {
  int i, j;

  SDL_SetRenderDrawColor( renderer, bg_col->r, bg_col->g, bg_col->b, SDL_ALPHA_OPAQUE );
  SDL_RenderClear( renderer );

  SDL_SetRenderDrawColor( renderer, HIDDED_FACTOR * col->r, HIDDED_FACTOR * col->g, HIDDED_FACTOR * col->b, SDL_ALPHA_OPAQUE );
  for ( i = 0; i < NFACES; i++ )
    for ( j = 0; j < POINTS_PER_SIDE; j++ )
      SDL_RenderDrawLine(
        renderer,
        faces[i][j].x * scale + xshift,
        faces[i][j].y * scale + yshift,
        faces[i][(j + 1) % POINTS_PER_SIDE].x * scale + xshift,
        faces[i][(j + 1) % POINTS_PER_SIDE].y * scale + yshift );

  SDL_RenderPresent(renderer);
}*/

void renderCrosshair( SDL_Surface *surf, int w, int h, int r ){
  int mx = w/2, my = h/2;
  struct point2d p1, p2;

  p1.x = mx - r;
  p2.x = mx + r;
  p1.y = p2.y = my;
  bresenhamInv(surf, &p1, &p2);
  p1.y = p2.y = my + 1;
  bresenhamInv(surf, &p1, &p2);

  p1.y = my - r;
  p2.y = my - 1;
  p1.x = p2.x = mx;
  bresenhamInv(surf, &p1, &p2);
  p1.x = p2.x = mx + 1;
  bresenhamInv(surf, &p1, &p2);

  p1.y = my + 2;
  p2.y = my + r;
  p1.x = p2.x = mx;
  bresenhamInv(surf, &p1, &p2);
  p1.x = p2.x = mx + 1;
  bresenhamInv(surf, &p1, &p2);
}

// afiseaza obiectul din faces[][] pe ecran
void renderObjectPerspective( struct Mesh *faces, SDL_Renderer* renderer, proj *pfunc, struct point *fuga, double xshift, double yshift, double scale, SDL_Color *col, SDL_Color *bg_col, int cross ) {
  SDL_Surface* surf;
  SDL_Texture* texture;
  int i, j, rawi, w, h, aux, p;
  double x, y;
  int ord[NFACES];
  int show_all, show_any;
  struct point2d proj[NPOINTS];
  int show[NPOINTS];

  struct point2d *tmp_proj[POINTS_PER_SIDE];
  SDL_Color *tmp_col[POINTS_PER_SIDE];

  SDL_GetRendererOutputSize(renderer, &w, &h);
  surf = SDL_CreateRGBSurface(0, w, h, 32, bg_col->r, bg_col->g, bg_col->b, bg_col->a);
  SDL_LockSurface(surf);

  sortZ(faces, ord);

  // proiectam din 3d in 2d
  for( i = 0 ; i < faces->np ; i++ ){
    show[i] = pfunc(fuga, &faces->p[i], &x, &y);
    proj[i].x = round(x * scale + xshift);
    proj[i].y = round(y * scale + yshift);
  }

  for( rawi = 0; rawi < faces->nf ; rawi++ ){
    i = ord[rawi];// gasim fata coresp in ord. dupa z

    show_all = 1;
    show_any = 0;
    for( j = 0 ; j < POINTS_PER_SIDE ; j++ ){
      aux = show[p = faces->fp[i][j]];
      if( proj[p].x < 0 || proj[p].x > w || proj[p].y < 0 || proj[p].y > h )
        aux = 0;

      show_all = show_all && show[p];
      show_any = show_any || aux;
    }

    if( show_any ){
      // umplem patrulaterul cu negru
      if( show_all ){
        for( j = 0 ; j < POINTS_PER_SIDE ; j++ ){
          tmp_col[j] = &faces->pc[faces->fp[i][j]];
          tmp_proj[j] = &proj[faces->fp[i][j]];
        }
        
        fillpollyconvex(surf, tmp_proj, tmp_col, POINTS_PER_SIDE);
      }
    }
  }

  if( cross )
    renderCrosshair(surf, w, h, 10);
  
  SDL_UnlockSurface(surf);

  // put surface on screen
  texture = SDL_CreateTextureFromSurface(renderer, surf);
  SDL_FreeSurface(surf);
  SDL_RenderCopy(renderer, texture, NULL, NULL);
  SDL_DestroyTexture(texture);
}

void renderInfo( SDL_Renderer *renderer, SDL_Color *col, double fps, int object, unsigned char ch2seg[128] ){
  SDL_Surface* surf;
  SDL_Texture* texture;
  SDL_Rect r1;
  char tmp_str[16];
  int w = 100, h = 3 * TEXT_CH_DIST + 2 * 2 * TEXT_SIZE;

  surf = SDL_CreateRGBSurface(0, w, h, 32, 0, 0, 0, 0);
  SDL_LockSurface(surf);

  sprintf(tmp_str, "%d fps", (int)fps);
  renderSevenSegStr(surf, tmp_str, col, TEXT_CH_DIST, TEXT_CH_DIST, ch2seg);
  
  sprintf(tmp_str, "obj %d", object);
  renderSevenSegStr(surf, tmp_str, col, TEXT_CH_DIST, TEXT_SIZE * 2 + 2 * TEXT_CH_DIST, ch2seg);

  r1.x = TEXT_CH_DIST;
  r1.y = TEXT_CH_DIST;
  r1.w = w;
  r1.h = h;

  // put surface on screen
  texture = SDL_CreateTextureFromSurface(renderer, surf);
  SDL_FreeSurface(surf);
  SDL_RenderCopy(renderer, texture, NULL, &r1);
  SDL_DestroyTexture(texture);
}
