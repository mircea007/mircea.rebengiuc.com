#ifndef MY_GRAPHICS_PROG_HEADER// ca sa nu se puna de 2 ori daca dau in 2 locuri include
#define MY_GRAPHICS_PROG_HEADER TRUE

// libraries
#include <SDL2/SDL.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>

// flags
//#define CUBE

// constants
#define DEFAULT_SCALE 40.0
#define DALPHA (M_PI / 40)
#define INITIAL_ALPHA DALPHA
#define MESH_DENSITY 100
#define POINTS_PER_SIDE 4
#define MAX_COL 255
#define TEXT_SIZE 8
#define TEXT_CH_DIST 4
#define NUM_FUNC 7
#define NUM_PROJ 2
//#define HIDDED_FACTOR 1// pentru culorile linilor ascunse (nu merge hidden lines deci l-am facut 1)

#define NFACES  ((MESH_DENSITY + 1) * (MESH_DENSITY + 1))// in cazul in care suprafata este continua se va atinge
#define NPOINTS ((MESH_DENSITY + 1) * (MESH_DENSITY + 1))

// structures
struct point { double x, y, z; };
struct point2d { int x, y; };

struct Mesh {
  // meta
  int np, nf;// number of points/faces
  
  // geometry
  struct point p[NPOINTS];// points
  SDL_Color pc[NPOINTS];// point colors
  int fp[NFACES][POINTS_PER_SIDE];// describes what points each face contains

  // auxilary structures
  struct point norm[NPOINTS];// normals
};

typedef void function( struct Mesh *, double, double, int, int );
typedef int proj( struct point *, struct point *, double *, double * );

// projection functions
int perspective( struct point *fuga, struct point *p, double *x, double *y );
int paralel( struct point *useless, struct point *p, double *x, double *y );

// math functions
void transfObject( struct Mesh *faces, struct Mesh *rot, double alphax, double alphay, double alphaz );
void getObjectLighting( struct Mesh *faces, struct point light_dir );
 
// face generation
void getNorm( struct Mesh *faces );
void sortZ( struct Mesh *faces, int ord[NFACES] );
void zqsort( double z[NFACES], int ord[NFACES], int begin, int end );

// object generation
void eggpack( struct Mesh *faces, double w, double h, int w_dens, int h_dens );
void wave( struct Mesh *faces, double w, double h, int w_dens, int h_dens );
void hat( struct Mesh *faces, double w, double h, int w_dens, int h_dens );
void cone( struct Mesh *faces, double w, double h, int w_dens, int h_dens );
void sarpe( struct Mesh *faces, double w, double h, int w_dens, int h_dens );
void crazytube( struct Mesh *faces, double w, double h, int w_dens, int h_dens );
void donut( struct Mesh *faces, double w, double h, int w_dens, int h_dens );

// rendering
void renderObjectPerspective( struct Mesh *faces, SDL_Renderer* renderer, proj *pfunc, struct point *fuga, double xshift, double yshift, double scale, SDL_Color *col, SDL_Color *bg_col, int cross );
void renderInfo( SDL_Renderer *renderer, SDL_Color *col, double fps, int object, unsigned char ch2seg[128] );

// misc
void initSevenSegment( unsigned char ch2seg[128] );
long long getTimeStamp();

#endif
