#include "grafica.h"

//  face structure:
//
//  0           3
//   +---------+
//   |         |
//   |         |
//   |         |
//   +---------+
//  1           2
//
//  point 4 is used for hidden lines


void eggpack( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;

  faces->np = (w_dens + 1) * (h_dens + 1);
  faces->nf = w_dens * h_dens;
  
  // generam punctele
  for( i = 0 ; i <= w_dens ; i++ ){
    for( j = 0 ; j <= h_dens ; j++ ){
      // calculam coordonata
      p = i * (h_dens + 1) + j;
      faces->p[p].x = -w + (2 * w * i) / w_dens;
      faces->p[p].z = -h + (2 * h * j) / h_dens;
      faces->p[p].y = sin(faces->p[p].x) * sin(faces->p[p].z);
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * h_dens + j;
      faces->fp[f][0] = (i    ) * (h_dens + 1) + (j    );
      faces->fp[f][1] = (i + 1) * (h_dens + 1) + (j    );
      faces->fp[f][2] = (i + 1) * (h_dens + 1) + (j + 1);
      faces->fp[f][3] = (i    ) * (h_dens + 1) + (j + 1);
    }
  }
}

void wave( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;
  double alpha, dist;

  // w nu se foloseste

  faces->np = 1 + w_dens * h_dens;
  faces->nf = w_dens * h_dens;

  faces->p[0].y = cos(0);
  faces->p[0].x = faces->p[0].z = 0;

  // generam punctele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      // calculam coordonata
      p = 1 + i * (h_dens) + j;
      alpha = i * 2.0 * M_PI / w_dens;
      dist = (j + 1) * h / h_dens;
      faces->p[p].x = dist * cos(alpha);
      faces->p[p].y = cos(dist);
      faces->p[p].z = dist * sin(alpha);
      faces->pc[p].a = SDL_ALPHA_OPAQUE;
      faces->pc[p].r = 255;
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * (h_dens) + j;
      faces->fp[f][0] = 1 + (i    ) * h_dens + j;
      faces->fp[f][1] = 1 + ((i + 1) % w_dens) * h_dens + j;
      if( j > 0 ){
        faces->fp[f][2] = 1 + ((i + 1) % w_dens) * h_dens + (j - 1);
        faces->fp[f][3] = 1 + (i    ) * h_dens + (j - 1);
      }else{
        faces->fp[f][2] = 0;
        faces->fp[f][3] = 0;
      }
    }
  }
}

void hat( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;
  double alpha, dist;

  // w nu se foloseste

  faces->np = 1 + w_dens * h_dens;
  faces->nf = w_dens * h_dens;

  faces->p[0].y = 0;
  faces->p[0].x = faces->p[0].z = 0;

  // generam punctele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      // calculam coordonata
      p = 1 + i * (h_dens) + j;
      alpha = i * 2.0 * M_PI / w_dens;
      dist = (j + 1) * h / h_dens;
      faces->p[p].x = dist * cos(alpha);
      faces->p[p].z = dist * sin(alpha);
      faces->p[p].y = (3 * dist * dist - 3.6 * dist * dist * dist + dist * dist * dist * dist);
      faces->pc[p].a = SDL_ALPHA_OPAQUE;
      faces->pc[p].r = 255;
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * (h_dens) + j;
      faces->fp[f][0] = 1 + (i    ) * h_dens + j;
      faces->fp[f][1] = 1 + ((i + 1) % w_dens) * h_dens + j;
      if( j > 0 ){
        faces->fp[f][2] = 1 + ((i + 1) % w_dens) * h_dens + (j - 1);
        faces->fp[f][3] = 1 + (i    ) * h_dens + (j - 1);
      }else{
        faces->fp[f][2] = 0;
        faces->fp[f][3] = 0;
      }
    }
  }
}

void cone( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;
  double alpha, dist;

  faces->np = 1 + w_dens * h_dens;
  faces->nf = w_dens * h_dens;

  faces->p[0].y = h;
  faces->p[0].x = faces->p[0].z = 0;

  // generam punctele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      // calculam coordonata
      p = 1 + i * (h_dens) + j;
      alpha = i * 2.0 * M_PI / w_dens;
      dist = (j + 1) * w / w_dens;
      faces->p[p].x = dist * cos(alpha);
      faces->p[p].z = dist * sin(alpha);
      faces->p[p].y = h - h * dist / w;
      faces->pc[p].a = SDL_ALPHA_OPAQUE;
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * (h_dens) + j;
      faces->fp[f][0] = 1 + (i    ) * h_dens + j;
      faces->fp[f][1] = 1 + ((i + 1) % w_dens) * h_dens + j;
      if( j > 0 ){
        faces->fp[f][2] = 1 + ((i + 1) % w_dens) * h_dens + (j - 1);
        faces->fp[f][3] = 1 + (i    ) * h_dens + (j - 1);
      }else{
        faces->fp[f][2] = 0;
        faces->fp[f][3] = 0;
      }
    }
  }
}

void sarpe( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;
  double alpha;

  faces->np = (w_dens + 1) * h_dens;
  faces->nf = w_dens * h_dens;

  // generam punctele
  for( i = 0 ; i <= w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      // calculam coordonata
      p = i * h_dens + j;
      alpha = j * 2 * M_PI / h_dens;
      faces->p[p].x = -w + i * 2 * w / w_dens;
      faces->p[p].y = cos(alpha);
      faces->p[p].z = sin(alpha) + h * cos(faces->p[p].x);
      faces->pc[p].a = SDL_ALPHA_OPAQUE;
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * (h_dens) + j;
      faces->fp[f][0] = (i    ) * h_dens + j;
      faces->fp[f][1] = (i + 1) * h_dens + j;
      faces->fp[f][2] = (i + 1) * h_dens + (j + 1) % h_dens;
      faces->fp[f][3] = (i    ) * h_dens + (j + 1) % h_dens;
    }
  }
}

void crazytube( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;
  double alpha;

  faces->np = (w_dens + 1) * h_dens;
  faces->nf = w_dens * h_dens;

  // generam punctele
  for( i = 0 ; i <= w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      // calculam coordonata
      p = i * h_dens + j;
      alpha = j * 2 * M_PI / h_dens;
      faces->p[p].x = -w + i * 2 * w / w_dens;
      faces->p[p].y = h * cos(alpha) * (2 + sin(faces->p[p].x)) / 3;
      faces->p[p].z = h * sin(alpha) * (2 + sin(faces->p[p].x)) / 3;
      faces->pc[p].a = SDL_ALPHA_OPAQUE;
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * (h_dens) + j;
      faces->fp[f][0] = (i    ) * h_dens + j;
      faces->fp[f][1] = (i + 1) * h_dens + j;
      faces->fp[f][2] = (i + 1) * h_dens + (j + 1) % h_dens;
      faces->fp[f][3] = (i    ) * h_dens + (j + 1) % h_dens;
    }
  }
}

void donut( struct Mesh *faces, double w, double h, int w_dens, int h_dens ) {// 1/2 din latura patratului meshului
  int i, j, p, f;
  double a, b;

  faces->np = w_dens * h_dens;
  faces->nf = w_dens * h_dens;

  // generam punctele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      // calculam coordonata
      p = i * h_dens + j;
      a = i * 2 * M_PI / w_dens;
      b = j * 2 * M_PI / h_dens;
      faces->p[p].x = cos(a) * w + h;
      faces->p[p].y = sin(a) * w;
      faces->p[p].z = -sin(b) * faces->p[p].x;
      faces->p[p].x *= cos(b);
      faces->pc[p].a = SDL_ALPHA_OPAQUE;
    }
  }

  // generam fetele
  for( i = 0 ; i < w_dens ; i++ ){
    for( j = 0 ; j < h_dens ; j++ ){
      f = i * h_dens + j;
      faces->fp[f][0] = (i               ) * h_dens + j;
      faces->fp[f][1] = ((i + 1) % w_dens) * h_dens + j;
      faces->fp[f][2] = ((i + 1) % w_dens) * h_dens + (j + 1) % h_dens;
      faces->fp[f][3] = (i               ) * h_dens + (j + 1) % h_dens;
    }
  }
}

// adauga (p2 - p1) x (p3 - p1) la norm
// 90% copy/paste de la domnul francu
void addNorm( struct point *p1, struct point *p2, struct point *p3, struct point *norm ){
  double x, y, z, x1, y1, z1, x2, y2, z2, modulus;

  // primul vector
  x1 = p2->x - p1->x;
  y1 = p2->y - p1->y;
  z1 = p2->z - p1->z;

  // primul vector
  x2 = p3->x - p1->x;
  y2 = p3->y - p1->y;
  z2 = p3->z - p1->z;

  // produsul lor vectorial este:
  // (y1 * z2 - z1 * y2, z1 * x2 - x1 * z2, x1 * y2 - y1 * x2)
  x = y1 * z2 - z1 * y2;
  y = z1 * x2 - x1 * z2;
  z = x1 * y2 - y1 * x2;

  modulus = sqrt( x * x + y * y + z * z ); // normalizam

  // adunam la suma normalelor
  norm->x += x / modulus;
  norm->y += y / modulus;
  norm->z += z / modulus;
}

void getNorm( struct Mesh *faces ){
  int f, p1, p2, p3;
  int nnorm[NPOINTS];

  for( p1 = 0 ; p1 < faces->np ; p1++ )
    nnorm[p1] = faces->norm[p1].x = faces->norm[p1].y = faces->norm[p1].z = 0;
  
  for( f = 0 ; f < faces->nf ; f++ ){
    for( p1 = 0 ; p1 < POINTS_PER_SIDE ; p1++ ){
      p2 = (p1 + 1) % POINTS_PER_SIDE;
      if( faces->fp[f][p2] == faces->fp[f][p1] )
        p2 = (p2 + 1) % POINTS_PER_SIDE;

      p3 = (p1 + POINTS_PER_SIDE - 1) % POINTS_PER_SIDE;
      if( faces->fp[f][p3] == faces->fp[f][p1] )
        p3 = (p3 + POINTS_PER_SIDE - 1) % POINTS_PER_SIDE;

      nnorm[faces->fp[f][p1]]++;

      addNorm(&faces->p[faces->fp[f][p1]], &faces->p[faces->fp[f][p2]], &faces->p[faces->fp[f][p3]], &faces->norm[faces->fp[f][p1]]);
    }
  }
  
  for( p1 = 0 ; p1 < faces->np ; p1++ )
    if( nnorm[p1] ){
      faces->norm[p1].x /= nnorm[p1];
      faces->norm[p1].y /= nnorm[p1];
      faces->norm[p1].z /= nnorm[p1];
    }else
      faces->norm[p1].x = faces->norm[p1].y = faces->norm[p1].z = 0;
}

void sortZ( struct Mesh *faces, int ord[NFACES] ){
  double z[NFACES];
  int i, j;

  for( i = 0 ; i < faces->nf ; i++ ){
    z[i] = 0.0;
    for( j = 0 ; j < POINTS_PER_SIDE ; j++ )
      z[i] += faces->p[faces->fp[i][j]].z;
  }

  for( i = 0 ; i < faces->nf ; i++ )
    ord[i] = i;
  
  zqsort( z, ord, 0, faces->nf - 1 );
}

void zqsort( double z[NFACES], int ord[NFACES], int begin, int end ){
  int b = begin - 1, e = end + 1, aux;
  double p = z[ord[(begin + end) / 2]];

  while( z[ord[++b]] < p );
  while( z[ord[--e]] > p );

  while( b < e ){
    aux = ord[b];
    ord[b] = ord[e];
    ord[e] = aux;

    while( z[ord[++b]] < p );
    while( z[ord[--e]] > p );
  }

  if( begin < e )
    zqsort(z, ord, begin, e);
  if( e + 1 < end )
    zqsort(z, ord, e + 1, end);
}
